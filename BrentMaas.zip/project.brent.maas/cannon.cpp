//Sebastiaan Alvarez Rodriguez - s1810979
//Brent Maas                   - s1826247
#include <stdlib.h>
#include "GL/glut.h"
#define _USE_MATH_DEFINES
#include <math.h>
#include <time.h>

#define MAXPARTICLES 1000

float g_posX = 0.0, g_posY = 25.0, g_posZ = 50.0;
float g_orientation = 15.0; // y axis

const static float orig_posX = g_posX, orig_posY = g_posY, orig_posZ = g_posZ,
      orig_orientation = g_orientation,
      g = 9.81, G = 50;

static bool gravity_toggle = false, well_toggle = false;
struct pinfo{
       float width;
       float x, y, z;
       float v_x, v_y, v_z;
       float r, g, b;
} particles[MAXPARTICLES];

void fireCannon()
{
       unsigned int i;
       for (i = 0; i < MAXPARTICLES; i = i + 1)
       {
               particles[i].width = 3.0 * (rand() / (float)RAND_MAX) + 1.0;
               particles[i].x = 0.0;
               particles[i].y = 0.0;
               particles[i].z = 0.0;
               particles[i].v_x = 5.0 * (rand() / (float)RAND_MAX) - 2.5;
               particles[i].v_y = 15.0 * (rand() / (float)RAND_MAX) + 10.0; // always upwards
               particles[i].v_z = 5.0 * (rand() / (float)RAND_MAX) - 2.5;
               particles[i].r = 1.0 * (rand() / (float)RAND_MAX);
               particles[i].g = 1.0 * (rand() / (float)RAND_MAX);
               particles[i].b = 1.0 * (rand() / (float)RAND_MAX);
       }
       glutGet(GLUT_ELAPSED_TIME);
}

void doExplosion()
{
	   const float height = 50.0 * (rand() / (float)RAND_MAX) + 10.0,
	   r = 1.0 * (rand() / (float)RAND_MAX),
	   		 g = 1.0 * (rand() / (float)RAND_MAX),
	   		 b = 1.0 * (rand() / (float)RAND_MAX);
       
       unsigned int i;
       for (i = 0; i < MAXPARTICLES; i = i + 1)
       {
               particles[i].width = 3.0 * (rand() / (float)RAND_MAX) + 1.0;
               particles[i].x = 0.0;
               particles[i].y = height;
               particles[i].z = 0.0;
               particles[i].v_x = 20.0 * (rand() / (float)RAND_MAX) - 10;
               particles[i].v_y = 20.0 * (rand() / (float)RAND_MAX) - 10;
               particles[i].v_z = 20.0 * (rand() / (float)RAND_MAX) - 10;
               particles[i].r = r;
               particles[i].g = g;
               particles[i].b = b;
       }
       glutGet(GLUT_ELAPSED_TIME);
}
void drawOneParticle()
{
       glBegin(GL_TRIANGLE_STRIP);
       // triangle 1
       glVertex3f(-0.5, 0.0, 0.5); // A
       glVertex3f(0.0, 0.0, -0.5); // B
       glVertex3f(0.0, 1.0, 0.0); // top
       // triangle 2
       glVertex3f(0.5, 0.0, 0.5); // C
       // triangle 3
       glVertex3f(-0.5, 0.0, 0.5); // A again
       // triangle 4 (bottom)
       glVertex3f(0.0, 0.0, -0.5); // B again
       glEnd();
}

void drawParticles()
{
       unsigned int i;
       for (i = 0; i < MAXPARTICLES; i = i + 1)
       {
               glPushMatrix();
               glTranslatef(particles[i].x, particles[i].y, particles[i].z);
               glScalef(particles[i].width, particles[i].width, particles[i].width);
               glColor3f(particles[i].r, particles[i].g, particles[i].b);
               drawOneParticle();
               glPopMatrix();
       }
       if(well_toggle){
       	   glPushMatrix();
           glTranslatef(0, 50, 0);
           glColor3f(1, 1, 1);
           drawOneParticle();
           glPopMatrix();
       }
}

void keyboard(unsigned char key, int x, int y) {
   switch (key) {
       case 'a': // up
           g_posY = g_posY + 1.0;
           break;
       case 'z': // down
           g_posY = g_posY - 1.0;
           break;
       case 'j': // left
           g_orientation = g_orientation - 15.0;
           break;
       case 'l': // right
           g_orientation = g_orientation + 15.0;
           break;
       case 'i': // forwards
           g_posX = g_posX + sin(g_orientation / 180.0 * M_PI);
           g_posZ = g_posZ - cos(g_orientation / 180.0 * M_PI);
           break;
       case 'k': // backwards
           g_posX = g_posX - sin(g_orientation / 180.0 * M_PI);
           g_posZ = g_posZ + cos(g_orientation / 180.0 * M_PI);
            break;
       case 'h': // reset 
            g_posX = orig_posX, g_posY = orig_posY, g_posZ = orig_posZ,
            g_orientation = orig_orientation;
           break;
       case 'f': // fire
           fireCannon();
           break;
       case 'r': // explosion
       	   doExplosion();
       	   break;
       case 'g': //gravity
       	   if (!well_toggle)
       	   	    gravity_toggle = !gravity_toggle;
       	   break;
       case 'w': //gravity well
           well_toggle = !well_toggle;
           gravity_toggle = false;
           break;
       case 'q': // exit
           exit(0);
           break;
   }
   glutPostRedisplay();
}

void update()
{
       glMatrixMode(GL_MODELVIEW);
       glLoadIdentity();
       glRotatef(g_orientation, 0.0, 1.0, 0.0); // rotate in y axis
       glTranslatef(-g_posX, -g_posY, -g_posZ);

       glClear(GL_COLOR_BUFFER_BIT);
       glClear(GL_DEPTH_BUFFER_BIT);

       glColor3f(1.0, 1.0, 1.0);
       // cannon base
       glBegin(GL_QUADS);
       glVertex3f(-5.0, 0.0, -5.0);
       glVertex3f(-5.0, 0.0, 5.0);
       glVertex3f(5.0, 0.0, 5.0);
       glVertex3f(5.0, 0.0, -5.0);
       glEnd();
       // ground plane
       glBegin(GL_LINE_STRIP);
       glVertex3f(-40.0, 0.0, -40.0);
       glVertex3f(-40.0, 0.0, 40.0);
       glVertex3f(40.0, 0.0, 40.0);
       glVertex3f(40.0, 0.0, -40.0);
       glVertex3f(-40.0, 0.0, -40.0);
       glEnd();

       drawParticles();
       glutSwapBuffers();
}

void timer(int value)
{
       unsigned int i;
       static int lastTime;
       int thisTime;
       float time;
       thisTime = glutGet(GLUT_ELAPSED_TIME);
       time = (thisTime - lastTime) / 500.0;
       lastTime = thisTime;
       for (i = 0; i < MAXPARTICLES; i = i + 1)
       {
       		   if (gravity_toggle) particles[i].v_y -= g * time;
               if (well_toggle){
                   float dx = -particles[i].x;
                   float dy = 50 - particles[i].y;
                   float dz = -particles[i].z;
                   float d = sqrtf(dx*dx + dy*dy + dz*dz);
                   dx /= d;
                   dy /= d;
                   dz /= d;
                   particles[i].v_x += dx * G / (d*d);
                   particles[i].v_y += dy * G / (d*d);
                   particles[i].v_z += dz * G / (d*d);
               }

               particles[i].y = particles[i].y + particles[i].v_y*time;
               
               if(particles[i].y <= 0 && gravity_toggle) {
               	particles[i].y = 0;
                particles[i].v_x = 0;
                particles[i].v_y = 0;
                particles[i].v_z = 0;
               	continue;
               }
               particles[i].x = particles[i].x + particles[i].v_x*time;
               particles[i].z = particles[i].z + particles[i].v_z*time;
       }
       glutPostRedisplay();
       glutTimerFunc(50, &timer, 0);
}

int main(int argc, char *argv[])
{
       srand(time(NULL));
       glutInit(&argc, argv);
       glutInitDisplayMode (GLUT_DOUBLE);
       glutCreateWindow("Particle Cannon");
       glMatrixMode(GL_PROJECTION);
       gluPerspective(120.0, 1.0, 1.0, 1000.0);
       glEnable(GL_DEPTH_TEST);
       glutDisplayFunc(&update);
       glutKeyboardFunc(&keyboard);
       glutTimerFunc(50, &timer, 0);
       glutMainLoop();
       return 0;
}
